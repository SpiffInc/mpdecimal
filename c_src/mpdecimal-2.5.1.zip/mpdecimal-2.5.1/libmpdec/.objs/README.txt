
Directory for shared object files
=================================

   symbols32.exp ==> 32-bit libmpdec API

   symbols64.exp ==> 64-bit libmpdec API

   libmpdec.imp ==> AIX import file
